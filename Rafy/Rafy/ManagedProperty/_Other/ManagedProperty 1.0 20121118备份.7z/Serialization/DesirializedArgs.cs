﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace OEA.Serialization
{
    //for extend
    public class DesirializedArgs { }
}
