﻿/*******************************************************
 * 
 * 作者：胡庆访
 * 创建时间：20111110
 * 说明：此文件只包含一个类，具体内容见类型注释。
 * 运行环境：.NET 4.0
 * 版本号：1.0.0
 * 
 * 历史记录：
 * 创建文件 胡庆访 20111110
 * 
*******************************************************/

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ComponentModel;
using System.Linq.Expressions;
using System.Security.Permissions;
using System.Security;
using OEA.Serialization.Mobile;
using System.Reflection;
using OEA.Reflection;

namespace OEA.ManagedProperty
{
    /// <summary>
    /// 托管属性对象
    /// </summary>
    [Serializable]
    [CompiledPropertyDeclarer]
    public abstract partial class ManagedPropertyObject : INotifyPropertyChanged, ICustomTypeDescriptor
    {
        #region Fields

        [NonSerialized]
        private ConsolidatedTypePropertiesContainer _container;

        private ManagedPropertyObjectFieldsManager _fields;

        private IManagedPropertyField[] CompiledFields
        {
            get { return this._fields._compiledFields; }
        }

        #endregion

        public ManagedPropertyObject()
        {
            this._fields = new ManagedPropertyObjectFieldsManager(this);
        }

        /// <summary>
        /// 本对象所有的属性容器
        /// </summary>
        public ConsolidatedTypePropertiesContainer PropertiesContainer
        {
            get
            {
                if (this._container == null) { this._container = this.FindPropertiesContainer(); }

                return this._container;
            }
        }

        protected virtual ConsolidatedTypePropertiesContainer FindPropertiesContainer()
        {
            return ManagedPropertyRepository.Instance.GetTypePropertiesContainer(this.GetType());
        }

        #region GetProperty / SetProperty / ClearProperty

        /// <summary>
        /// 可以通过字符串来查找可用的托管属性。
        /// </summary>
        /// <param name="managedProperty"></param>
        /// <returns></returns>
        public IManagedProperty FindProperty(string managedProperty)
        {
            if (string.IsNullOrWhiteSpace(managedProperty)) throw new ArgumentNullException("managedProperty");

            var list = this.PropertiesContainer.GetAvailableProperties();
            for (int i = 0, c = list.Count; i < c; i++)
            {
                var property = list[i];
                if (property.Name == managedProperty) return property;
            }

            return null;
        }

        /// <summary>
        /// 重设属性为默认值
        /// </summary>
        /// <param name="property"></param>
        public void ResetProperty(IManagedProperty property)
        {
            this._fields.ResetProperty(property);
        }

        /// <summary>
        /// 获取某个托管属性的值。
        /// </summary>
        /// <param name="property"></param>
        /// <returns></returns>
        public object GetProperty(IManagedProperty property)
        {
            return this._fields.GetProperty(property);
        }

        /// <summary>
        /// 获取某个托管属性的值。
        /// </summary>
        /// <typeparam name="TPropertyType"></typeparam>
        /// <param name="property"></param>
        /// <returns></returns>
        public TPropertyType GetProperty<TPropertyType>(ManagedProperty<TPropertyType> property)
        {
            return this._fields.GetProperty(property);
        }

        /// <summary>
        /// 设置某个托管属性的值。
        /// </summary>
        /// <param name="property"></param>
        /// <param name="value"></param>
        /// <param name="source">本次值设置的来源。</param>
        public void SetProperty(IManagedProperty property, object value, ManagedPropertyChangedSource source = ManagedPropertyChangedSource.FromProperty)
        {
            this._fields.SetProperty(property, value, source);
        }

        /// <summary>
        /// 设置某个托管属性的值。
        /// </summary>
        /// <typeparam name="TPropertyType"></typeparam>
        /// <param name="property"></param>
        /// <param name="value"></param>
        /// <param name="source">本次值设置的来源。</param>
        public void SetProperty<TPropertyType>(ManagedProperty<TPropertyType> property, TPropertyType value, ManagedPropertyChangedSource source = ManagedPropertyChangedSource.FromProperty)
        {
            this._fields.SetProperty(property, value, source);
        }

        /// <summary>
        /// LoadProperty 直接设置值，不发生 PropertyChanged 事件。
        /// </summary>
        /// <param name="property"></param>
        /// <param name="value"></param>
        public virtual void LoadProperty(IManagedProperty property, object value)
        {
            this._fields.LoadProperty(property, value);
        }

        /// <summary>
        /// LoadProperty 直接设置值，不发生 PropertyChanged 事件。
        /// </summary>
        /// <typeparam name="TPropertyType"></typeparam>
        /// <param name="property"></param>
        /// <param name="value"></param>
        public virtual void LoadProperty<TPropertyType>(ManagedProperty<TPropertyType> property, TPropertyType value)
        {
            this._fields.LoadProperty(property, value);
        }

        #endregion

        #region RegisterProperty

        /// <summary>
        /// Register Property
        /// </summary>
        /// <typeparam name="T">Type of Target</typeparam>
        /// <typeparam name="P">Type of property</typeparam>
        /// <param name="propertyLambdaExpression">Property Expression</param>
        /// <param name="defaultValue">Default Value for the property</param>
        /// <returns></returns>
        protected static ManagedProperty<P> RegisterProperty<T, P>(Expression<Func<T, object>> propertyLambdaExpression, P defaultValue)
        {
            var reflectedPropertyInfo = Reflect<T>.GetProperty(propertyLambdaExpression);

            var property = new ManagedProperty<P>(
                typeof(T), reflectedPropertyInfo.Name, new ManagedPropertyMetadata<P>()
                {
                    DefaultValue = defaultValue
                });

            ManagedPropertyRepository.Instance.RegisterProperty(property);

            return property;
        }

        #endregion

        #region PropertyChanged

        internal void RaisePropertyChanged(IManagedPropertyChangedEventArgs e)
        {
            this.OnPropertyChanged(e);

            var p = e.Property as IManagedPropertyInternal;

            var dependencies = p.ReadonlyDependencies;
            if (dependencies.Count > 0)
            {
                for (int i = 0, c = dependencies.Count; i < c; i++)
                {
                    var dp = dependencies[i] as IManagedPropertyInternal;
                    dp.RaiseReadOnlyPropertyChanged(this, e.Source);
                }
            }
        }

        /// <summary>
        /// 向子类公布一个方法，这样子类可以使用 IManagedProperty 来进行属性变更通知。
        /// 注意，这个方法发布的事件，NewValue、OldValue 将不可用。
        /// </summary>
        /// <param name="property"></param>
        /// <param name="source"></param>
        protected void OnPropertyChanged(IManagedProperty property, ManagedPropertyChangedSource source = ManagedPropertyChangedSource.FromProperty)
        {
            var propertyInternal = property as IManagedPropertyInternal;
            if (property.IsReadOnly)
            {
                propertyInternal.RaiseReadOnlyPropertyChanged(this, source);
            }
            else
            {
                var defaultValue = property.GetMeta(this).DefaultValue;
                var args = propertyInternal.CreatePropertyChangedArgs(this, defaultValue, defaultValue, source);
                this.RaisePropertyChanged(args);
            }
        }

        /// <summary>
        /// 子类重写此方法实现某个扩展属性变更后的处理函数
        /// </summary>
        /// <param name="e"></param>
        protected virtual void OnPropertyChanged(IManagedPropertyChangedEventArgs e)
        {
            this.OnPropertyChanged(e.Property.Name);
        }

        /// <summary>
        /// 子类重写此方法实现某个属性变更后的处理函数
        /// 默认实现中，会触发本对象的 PropertyChanged 事件。
        /// </summary>
        /// <param name="propertyName"></param>
        protected virtual void OnPropertyChanged(string propertyName)
        {
            var handler = this._propertyChangedHandlers;
            if (handler != null) handler(this, new PropertyChangedEventArgs(propertyName));
        }

        /// <summary>
        /// Implements a serialization-safe PropertyChanged event.
        /// </summary>
        [NonSerialized]
        private PropertyChangedEventHandler _propertyChangedHandlers;

        public event PropertyChangedEventHandler PropertyChanged
        {
            add
            {
                _propertyChangedHandlers = (PropertyChangedEventHandler)
                  System.Delegate.Combine(_propertyChangedHandlers, value);
            }
            remove
            {
                _propertyChangedHandlers = (PropertyChangedEventHandler)
                  System.Delegate.Remove(_propertyChangedHandlers, value);
            }
        }

        #endregion

        #region 代理到 _fields 的接口

        /// <summary>
        /// 获取编译期属性值集合
        /// </summary>
        /// <returns></returns>
        public IEnumerable<IManagedPropertyField> GetCompiledPropertyValues()
        {
            return this._fields.GetCompiledPropertyValues();
        }

        /// <summary>
        /// 获取当前对象所有非默认值的属性值集合。
        /// </summary>
        /// <returns></returns>
        public IEnumerable<IManagedPropertyField> GetNonDefaultPropertyValues()
        {
            return this._fields.GetNonDefaultPropertyValues();
        }

        /// <summary>
        /// 是否存在属性值。
        /// </summary>
        /// <param name="propertyName"></param>
        /// <returns></returns>
        public bool FieldExists(string propertyName)
        {
            if (string.IsNullOrWhiteSpace(propertyName)) throw new ArgumentNullException("propertyName");

            var property = this.FindProperty(propertyName);
            if (property == null) return false;

            return this._fields.FieldExists(property);
        }

        /// <summary>
        /// 是否存在属性值。
        /// </summary>
        /// <param name="propertyName"></param>
        /// <returns></returns>
        public bool FieldExists(IManagedProperty property)
        {
            if (property == null) throw new ArgumentNullException("property");

            return this._fields.FieldExists(property);
        }

        #endregion

        #region ICustomTypeDescriptor Members

        PropertyDescriptorCollection ICustomTypeDescriptor.GetProperties(Attribute[] attributes)
        {
            return PropertyDescriptorFactory.Current.GetProperties(this.PropertiesContainer);
        }

        //以下实现复制自 DataRowView

        AttributeCollection ICustomTypeDescriptor.GetAttributes()
        {
            return new AttributeCollection(null);
        }
        string ICustomTypeDescriptor.GetClassName()
        {
            return null;
        }
        string ICustomTypeDescriptor.GetComponentName()
        {
            return null;
        }
        TypeConverter ICustomTypeDescriptor.GetConverter()
        {
            return null;
        }
        EventDescriptor ICustomTypeDescriptor.GetDefaultEvent()
        {
            return null;
        }
        PropertyDescriptor ICustomTypeDescriptor.GetDefaultProperty()
        {
            return null;
        }
        object ICustomTypeDescriptor.GetEditor(Type editorBaseType)
        {
            return null;
        }
        EventDescriptorCollection ICustomTypeDescriptor.GetEvents()
        {
            return new EventDescriptorCollection(null);
        }
        EventDescriptorCollection ICustomTypeDescriptor.GetEvents(Attribute[] attributes)
        {
            return new EventDescriptorCollection(null);
        }
        PropertyDescriptorCollection ICustomTypeDescriptor.GetProperties()
        {
            return ((ICustomTypeDescriptor)this).GetProperties(null);
        }
        object ICustomTypeDescriptor.GetPropertyOwner(PropertyDescriptor pd)
        {
            return this;
        }

        #endregion
    }
}