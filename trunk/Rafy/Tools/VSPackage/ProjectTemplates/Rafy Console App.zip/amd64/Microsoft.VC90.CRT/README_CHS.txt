﻿位于此文件夹中的文件不是 SQL Server Compact 文件。  
有关使用这些文件的条款和条件，请参阅 SQL Server Compact 4.0 软件许可条款中的 1b 部分。
